# Progue Avgstar — Design Spec & Edit Map

Companion to **`avgstar.html`**. This is the reference a future session reads first
to understand *what the design is* and *where each piece lives in the code*, so any
change request maps to an exact CSS class + `CONTENT` key and stays surgical.

> **Two variants exist. Do not confuse them.**
> - **Progue Nebula** — the older/existing site (the live `progue.ai` screenshots).
>   Smaller centered hero, flat low-contrast cards, plain pills, no backdrop.
>   *Reference only. Do not edit toward Nebula.*
> - **Progue Avgstar** — this build (`avgstar.html`). Full-screen, fixed Live
>   Logistics Map backdrop, Prompturtle-grade section structure, on the locked
>   space-blue + dark-purple system. **All work targets Avgstar.**

---

## 0. Two edit surfaces (where almost every change goes)

| Surface | Location in `avgstar.html` | Use for |
|---|---|---|
| **`:root` token block** | top `<style>` block | colors, spacing, type scale, veil, max-width |
| **`CONTENT` object** | top of `<script type="text/babel">` | all copy, labels, lists, prices, links |

Section components (`Nav`, `Hero`, `Problem`, …) only consume those two surfaces.
Structural/visual change → CSS class. Copy change → `CONTENT` key. Never hardcode
copy inside a component.

---

## 1. Full screen

**Decision:** edge-to-edge layout, hero fills the whole first viewport, fixed map
backdrop persists behind all content while scrolling. *Not* browser-fullscreen mode.

- Gutter: `--pad: clamp(20px,4.5vw,64px)` (edge padding, replaces a narrow centered column).
- Content rail: `--maxw: 1280px` (`.rail`). The **backdrop ignores the rail** — it's `position:fixed; inset:0`.
- Hero: `.hero { min-height:100vh }`.
- Backdrop layers (z-order): `#bg-canvas-wrap` (z0) → `#bg-scrim` (z1) → `#page` (z2) → `.footer` (z2).
- **Backdrop stays put on scroll** because the canvas wrap is `fixed`. Content slides over it.
- **Legibility veil:** below-hero sections use `.section.veiled { background:rgba(8,13,28,var(--section-veil)) }`.
  Dial map visibility with `--section-veil` (0 = map fully visible behind sections, 1 = solid).
  Currently `0.74`.

*Change "show more/less map behind content"* → `--section-veil`.
*Change overall map dimming* → `#bg-scrim` gradient.

---

## 2. Type scale

Geist (sans) + Geist Mono. **Stays Geist — do not switch to Space Grotesk.** Prompturtle's
influence is scale/rhythm, not the typeface.

| Element | Class | Size |
|---|---|---|
| Hero H1 | `.hero h1` | `clamp(44px,7vw,92px)`, weight 600, `-0.038em`, `line-height 1.0` |
| Section heading | `.section-h` | `clamp(30px,4vw,52px)`, weight 600, `-0.03em` |
| Final CTA H2 | `.final h2` | `clamp(34px,5vw,68px)` |
| Module title | `.mod-card h3` | `clamp(22px,2.2vw,30px)` |
| Lede / body | `.lede` | `clamp(15px,1.3vw,17px)`, `line-height 1.7`, color `--text2` |
| Mono eyebrow/label | `.mlabel`, `.hero .eyebrow` | 11–12px, `letter-spacing .18em`, uppercase, `--text3` |
| Mono note | `.mono-note` | 13px, `--text3` |

Nebula's hero was far too small; Avgstar's hero type must dominate the viewport.

---

## 3. Card patterns & anatomy

Four distinct card types. Each has a fixed anatomy — match it when adding items.

### 3a. Problem cards — `.prob-card` (CONTENT.problem.cards)
Right-column, **vertically stacked**, numbered. Anatomy:
`[mono index .idx] + [.ct title] + [.cd description]`, plus a **left accent bar**
(`::before`, 2px, color from `--c`). Hover: shift right + lift to `--raised`.
Item shape: `{n, t, d, c}` where `c` is the accent (see §4).

### 3b. Module cards — `.mod-card` (CONTENT.modules.cards)
Large rich cards, 2-col grid. Anatomy:
`[mono "Module · 0X" .mhead] + [.mod-card h3 title] + [.mdesc description] +
[two-column .mod-tools list] + [line-art .mod-glyph top-right]`.
Item shape: `{n, t, d, tools:[…], glyph}`. Glyph key ∈ `doc|tree|hex|branch|chain`
(defined in the `GLYPHS` map; accent node uses class `.hot`).

### 3c. Guardrail cards — `.guard-card` (CONTENT.guardrails.cards)
Compact 4-up. Anatomy: `[mono key .gk] + [.gt title] + [.gd description]`.
Item shape: `{k, t, d}`.

### 3d. Pricing cards — `.price-card` (see §8).

### 3e. Brand chips — `.brand-chip` (see §7).

**Rule:** new list items reuse the existing item shape; never restyle one card in isolation.

---

## 4. Contrast colors

Background + brand stay locked (`--bg #060B1A`, `--brand #5B3A82`). Contrast for cards
comes from **surface lift + cycling accent bars**, all inside the blue/purple family:

- Surfaces: `--surface #0C1326` (rest) → `--raised #111A33` (hover).
- Hairlines: `--hair` → `--hair-strong` (hover).
- Accent cycle for problem-card bars: `--brand` (#5B3A82) → `--info` (#3E6FA0) → `--brand-lift` (#7B5AA0).
- Module/guard accents: `--brand-lift` for mono labels + glyph `.hot` node.

Backdrop vehicles use atmospheric tints **only on the canvas** (planes `#A58CEB` violet,
ships `#58C8FF` blue, trucks `#F0CD6E` amber). These are *not* UI/brand colors and must
not leak into chrome. (This is the resolution of the earlier "sage tint" question — no sage anywhere.)

*Add a new accent* → add a CSS var in `:root`, reference via the item's `c` field.

---

## 5. Modules section (`03 / Phase 1 modules`) — `Modules()` / `.mod-grid`

Heading "Built for the logistics execution layer." then a 2-col grid of `.mod-card`
(see §3b). Five modules: BOL Processing, Carrier Rate Comparison, HTS/Customs, Approval
Workflow, Audit Trail. Each shows its MCP tool surface in the two-col `.mod-tools` list.
Glyphs are inline SVG (no icon font). *Nebula was flat title+tag+single bullet column;
Avgstar adds description, two-col tools, glyph, hover depth.*

---

## 6. Integration flowchart (`04 / How it integrates`) — `Integration()` / `.flowpanel`

Bordered panel with subtle grid background (`.grid-bg`, radial-masked). A node graph:
`Your product → Progue API → Context Engine → Claude (+ Audit log branch) → Your product`.

- Nodes: `.node` (`.node.brand` = highlighted Progue API). Shape `{nt title, ns sub}`.
- **Context Engine**: dashed `.engine` box listing the 5 layers as `.erow` (key + right label),
  from `CONTENT.integration.engine`. The `guardrails` row gets `.erow.g` (error-tint emphasis).
- **Animated transport connectors** `.conn`: each holds a `.line` + a `<Vehicle>` that
  travels left→right on loop. Sequence intentionally = **truck → ship → plane → truck**
  (land/sea/air, the supply-chain transport motif). Vehicle SVGs in `Vehicle({type})`;
  motion via `@keyframes travel`; colors `--warning/--cyan/--violet`.
- Mobile: `.flow` stacks vertically; `.conn` rotates 90°. *Known tweak point: vehicle
  orientation at narrow widths.*

*Reorder/recolor transport* → `Vehicle` usages inside `Integration()` + `.veh-*` classes.

---

## 7. "Built on" strip (`05 / Built on`) — `BuiltOn()` / `.builton`

Row of `.brand-chip` = **logo mark + wordmark** (not plain text pills, which is what
Nebula had). Marks are inline SVG in the `BrandMark` component, keyed by exact name string
from `CONTENT.builton.chips`. Caption `.builton-note` below.

*Swap to official brand SVGs* → replace the entry in `BrandMark`'s `map` (key must match
the chip string exactly). *Add a company* → push to `CONTENT.builton.chips` **and** add a
`BrandMark` map entry (falls back to a brand-lift dot if missing).

---

## 8. Pricing (`07 / Pricing`) — `Pricing()` / `.price-grid`

Three `.price-card`. Anatomy:
`[.price-top: mono .tier-name + right .tier-tag] + [.price-amt + .per] + [mono .price-meta] +
[.price-feats with check-circle <Check/> bullets] + [.price-cta]`.
Recommended tier: `.price-card.reco` + floating `.reco-flag` ("most teams start here").
Per-tier CTA label/style from item (`cta`, `ctaKind: solid|ghost`).

Item shape: `{name, tag, amt, per, meta:[…], feats:[…], cta, ctaKind, reco, flag?}`.
*Nebula used plain-dot bullets, one CTA style, no tier tags/flag.* Avgstar copies
Prompturtle's treatment but **keeps Nebula's numbers/feature copy** (in `CONTENT.pricing`).

---

## 9. Solutions page — NOT YET BUILT

`avgstar.html` is the **landing page only**. The `/solutions` and `/about` routes from the
screenshots are pending. When building Solutions:

- Nebula's version is a flat label-left / description-right list with hairline dividers — too plain.
- **Intended Avgstar treatment:** convert each buyer type (TMS Vendors, Freight Visibility,
  3PL Software, Procurement SaaS, Carrier Management) into an accent row or `.prob-card`-style
  block — index/glyph + title + description, hover state, reveal-on-scroll, space-blue/purple
  contrast. Reuse the §3 card anatomy rather than inventing a new one.
- Same applies to `/about` + footer (already styled): keep reveal + hover + contrast consistent.

---

## 10. Backdrop (Live Logistics Map) — engine notes

Plain-JS `<script>` above the babel block (ported from `atmos-core` + `world-geo` +
`concept-worldmap`; tweaks panel removed). Baked `SETTINGS`:
`accent #5B3A82, speed 1, meshIntensity 1, pointerStrength 0.32, planes/ships/trucks on`.
World = triangulated node-mesh; vehicles ride real sea/air/road routes; pointer "parts the
water" + click spawns ripples. Pauses RAF on tab-hidden; freezes under `prefers-reduced-motion`.

*Change accent options offered originally:* `#5B3A82` purple · `#2A6FDB` blue · `#1F8A5B` green · `#B0506A` rose.
*Tune liveliness* → `SETTINGS` constants.

---

## 11. Global behaviors

- **Reveal-on-scroll:** add class `reveal` to any element; `useReveal()` (IntersectionObserver)
  adds `.in`. Respects reduced-motion (everything shows immediately).
- **Nav:** transparent over hero, gains `.scrolled` (blur + hairline) past 20px.
- **Section labels:** `.mlabel` = `[.sq accent square] [.num] · [label]`, mono, from each section's `num`/`label`.
- **Responsive:** single breakpoint at 920px (grids collapse to 1-col, nav → burger, flow stacks).

---

## 12. Change-request → target cheat sheet

| Request mentions… | Go to |
|---|---|
| copy / wording / price numbers / link labels | `CONTENT.<section>` |
| color / accent / contrast / veil / map dimming | `:root` vars (+ `#bg-scrim`, `--section-veil`) |
| type size / heading scale | `:root` type rules (§2) |
| a card looks wrong | the matching `.prob-card`/`.mod-card`/`.guard-card`/`.price-card` (§3) |
| modules layout | `.mod-grid`, `.mod-card`, `GLYPHS` (§5) |
| flowchart / arrows / transport | `Integration()`, `.conn`, `Vehicle`, `@keyframes travel` (§6) |
| logos / built-on | `BrandMark` map + `CONTENT.builton.chips` (§7) |
| pricing layout / tiers / recommended flag | `.price-card`, `CONTENT.pricing.tiers` (§8) |
| solutions / about page | not built yet — §9 |
| backdrop speed / vehicles / accent | `SETTINGS` (§10) |
| animation appears/disappears on scroll | `reveal` class + `useReveal()` (§11) |
