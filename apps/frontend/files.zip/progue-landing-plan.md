# Progue.ai — Landing Page Design & Build Plan
**Version 1.0 · For: Cowork planning chat + Claude Code · Product: Progue.ai (B2B supply chain context engineering platform)**

---

## 0. How to use this document

Paste this whole file at the start of the landing-page build session in **Cowork** (to plan/sequence) and into **Claude Code** (to build). It is self-contained: it carries the locked design system, the competitive reasoning, the full page architecture with drafted copy, the animation spec, the editability architecture, and the build/deploy instructions. Nothing here requires re-explaining prior chats.

**The single most important rule for this build:** Progue's *service* matters more than the landing page's polish. This plan deliberately caps visual/animation effort and flags every "ship now, refine later" boundary so the page does not steal focus from completing Phase 6 (the actual ship). Build it well, ship it, move on.

---

## 1. Where this sits in the build (sequencing — non-negotiable)

The landing page is **not** interleaved with the Phase 6 PRs. It runs *after* the deploy gate. Confirmed order:

1. **PR 6.3** — E2E tests (Playwright). Merged.
2. **PR 6.4** — Production deploy config (Vercel + Railway). Merged. **Human runs the pre-deploy checklist in `docs/env-setup.md` top to bottom** (Supabase unpaused, migrations applied, Stripe LIVE seed + price IDs, Clerk prod instance, webhooks registered, DNS pointed). Only then does pushing to `main` fire the deploy jobs.
3. **🟣 GATE — domain confirmed live.** This is the literal trigger from the bottom of the PR 6.4 prompt: *"When this checkpoint comes in, the Vercel domain is live. Start the landing page."* The landing-page build **does not start before this point.** One hard thing at a time: get the product actually deployed and working first.
4. **PR 6.5** — Load test + API docs + `v0.6.0-ship` tag. This is backend/docs work and does **not** touch the marketing site, so the landing page build may run **in parallel** with 6.5 once the domain is live.
5. **Landing page** — built in `apps/frontend`, deployed to the now-live Vercel domain.

**Why this order:** By the time the page launches, the product is genuinely live — `app.progue.ai` dashboard works, `api.progue.ai` serves real endpoints, Stripe is in LIVE mode with real price IDs, the `pt_` key flow works. That is why this plan uses **real pricing** and a **real self-serve "Get API key" CTA** rather than a waitlist. The page announces a shipped product, not a promise.

---

## 2. Competitive synthesis (what to borrow, what to avoid)

Reference set: runlayer.com, langbase.com, x.ai, respan.ai — all dev-infrastructure landing pages selling to engineers.

**The genre has a settled structure.** Short punchy hero (3–7 words) + two CTAs → one *functional* signature animation that demonstrates the product → sharp problem statement → feature sections that show the actual mechanism → credibility strip → pricing → final CTA. Follow it; engineers expect it and it converts.

**Borrow:**
- **Langbase's live-trace hero.** Langbase shows "input → thinking → output" panels that literally display context being retrieved, reranked, cited. That *is* Progue's product. The single strongest move available — show a real decision flowing through guardrails. (See §4 Hero.)
- **Langbase's real-code credibility.** They show actual SDK code that types out and returns a result. Engineers trust code over adjectives.
- **Runlayer's sharp problem framing.** "The tools your teams love are leaking PII…" — a blunt, specific problem statement beats vague benefit copy.
- **The "built on" credibility move.** Both lean on recognizable infrastructure names. Progue does this honestly via a tech strip (no fake customers).

**Avoid:**
- **Runlayer's enterprise-logo wall.** They paper the page with customer logos and named exec quotes. Progue has no customers yet — faking or omitting this gracefully is mandatory. Use the tech strip instead (§4.6).
- **Over-animation.** x.ai is near-static and reads as serious. Resist GSAP-pinned-scroll spectacle; it eats build time and signals "marketing site" not "infrastructure." (See §5.)
- **Long marketing prose.** Engineers skim. Every section earns its place by answering "what does this actually do?"

---

## 3. Locked design system (shared with the dashboard — do not reinvent)

The landing page lives in the **same `apps/frontend` Vite app as the dashboard** and **reuses the exact same design tokens**. These already exist in the codebase as the dashboard theme; import them, do not redefine them. If they live in a theme file, the landing page imports from it. If not, create `apps/frontend/src/theme/tokens.ts` as the single source and refactor both surfaces to use it.

```
/* Surfaces */
--bg:            #060B1A   /* space blue — page background */
--surface:       #0C1326   /* cards, raised panels */
--surface-raised:#111A33   /* hover, elevated */
--border:        rgba(150,170,210,0.10)
--border-strong: rgba(150,170,210,0.16)

/* Text */
--text:   #EAE8F0   /* primary */
--text-2: #9590B0   /* secondary */
--text-3: #5E5A7A   /* muted */

/* Brand + status (status used sparingly, only where it carries meaning) */
--brand:   #5B3A82   /* dark purple — primary CTA, active states, the trace accent */
--success: #5BA88C
--warning: #C9A86A
--error:   #C36B7A
--info:    #3E6FA0

/* Type */
--sans: 'Geist', system-ui, sans-serif      /* UI + headings */
--mono: 'Geist Mono', ui-monospace, monospace /* code, numbers, labels, the trace */
```

**Aesthetic rules (inherited from the dashboard):** matte, no gradients except subtle radial fades, hairline borders only, no drop shadows, no glow. Wordmark is `progue.` in Geist weight 500 with the dark-purple dot. The page should feel like the same product as the dashboard — a visitor who signs up should feel zero visual discontinuity crossing from `progue.ai` to `app.progue.ai`.

---

## 4. Landing page architecture (scroll order, with drafted copy)

Each section is tagged **[LOCKED]** (structural, rarely changes) or **[EDIT-LATER]** (copy/data you'll tweak as the business evolves — lives in `content.ts`, see §6). Drafted copy is a starting point, not final — all of it is editable.

### 4.0 — Top nav **[LOCKED structure, EDIT-LATER links]**
Sticky, 56px, backdrop-blur, hairline bottom border, `--surface` background.
- Left: `progue.` wordmark (purple dot).
- Center/right: Solutions · Docs · Pricing · About (links to the sub-pages).
- Far right: primary pill CTA "Get API key →" (→ `app.progue.ai/sign-up`).

### 4.1 — Hero **[LOCKED structure, EDIT-LATER copy]**
- Mono eyebrow label: `SUPPLY CHAIN CONTEXT ENGINEERING`
- Headline (~7 words): **"Pre-built AI context for supply chain software."**
- Subhead (~25 words): "MCP servers, schemas, guardrails, memory, and audit trails for the logistics execution layer. Embed Progue's API and ship domain-specific agents in a week, not six."
- Two CTAs: primary "Get API key →" (`app.progue.ai/sign-up`), secondary "Read the docs" (`/docs`).
- **Signature animation (the centerpiece, see §5):** to the right of / below the copy, a two-panel demo. Left panel: a code block that *types itself out* — a real `progue.modules.hts.classify(...)` call using the SDK shape from the API reference. Right panel: as the code "runs," a **live trace** streams in — `call_received → guardrail: high_cost_approval check → decision → audit_logged` — each line appearing in sequence with its status dot (success/warning in palette colors). This demonstrates the product's actual differentiator: guardrailed, audited decisions. Loops slowly; respects `prefers-reduced-motion` (renders the completed end-state statically if motion is reduced).

### 4.2 — Problem **[EDIT-LATER]**
- Mono label: `01 / WHY BUILD CONTEXT FROM SCRATCH`
- One tight paragraph + three small cards. Borrow Runlayer's bluntness.
- Headline: **"Six to ten weeks of work before you ship a single decision."**
- Body: "Most teams budget for the model. The cost lives in everything around it — schemas, MCP tool wrappers, guardrail rules, audit logs, vector memory. All custom, all brittle, none of it your differentiator. One workflow typically burns ~$36,000 in engineering time before the first production decision."
- Three cards: "Schema design & validation" · "Guardrail rule engineering" · "Vector memory + audit trail."

### 4.3 — What it is / definition **[EDIT-LATER]**
- Mono label: `02 / CONTEXT ENGINEERING, NOT PROMPT ENGINEERING`
- Short confident definition + a six-item row (system prompts · schemas · MCP server · guardrails · memory · audit) each with a one-line description. This is the "show the mechanism" section.

### 4.4 — The five modules **[EDIT-LATER]** ← this list WILL grow as Phase 2 ships
- Mono label: `03 / PHASE 1 MODULES`
- Headline: **"Built for the logistics execution layer."**
- Five cards (data-driven from `content.ts` so adding Phase 2 modules later is a config edit): **BOL Processor** (`parse · validate · extract_line_items · flag_compliance`), **Carrier Rates** (`compare_rates · score_carrier · estimate_transit · recommend`), **HTS Classifier** (`classify_hs_code · lookup_tariff · check_cbam · flag_audit_risk`), **Approval Workflow** (`request_approval · auto_approve_safe · escalate · record`), **Audit Trail** (`log_decision · list_history · export_report · verify_chain`).

### 4.5 — How it integrates **[EDIT-LATER]**
- Mono label: `04 / ONE API SURFACE`
- A simple architecture line (Your product → Progue API → Context Engine → Claude → Audit log → back to your product) + a real SDK code block (use the `classify` example shape from the API reference). Keep the diagram as inline SVG, flat, hairline.

### 4.6 — Built on (credibility strip) **[EDIT-LATER]**
- Mono label: `05 / BUILT ON`
- A single row of recognizable infrastructure names (text or simple logos): **Anthropic Claude · Anthropic MCP SDK · Supabase + pgvector · Clerk · Stripe · Resend · Vercel · Railway.**
- One line under it: "Every choice serves auditability or multi-tenancy."
- **This replaces customer logos** until real customers exist. When they do, add a customer-logo row above this as a new `content.ts` array — no layout change needed.

### 4.7 — Guardrails (strongest differentiator) **[EDIT-LATER]**
- Mono label: `06 / GUARDRAILS, NOT GUESSWORK`
- Headline: **"Every decision passes two gates and writes to an audit log."**
- A compact rule table (rule · condition · action · approver) using the real guardrails: `high_cost_approval` (>$10k → request approval, finance_manager) · `new_carrier_check` (carrier not approved → warn, ops_manager) · `customs_flag` (customs + unverified broker → halt + escalate, compliance_officer) · `schema_violation` (invalid input → reject). Action column tinted by status color.

### 4.8 — Pricing **[EDIT-LATER — high-churn, keep trivially editable]**
- Mono label: `07 / PRICING`
- Three cards, real numbers (driven from `content.ts`): **Starter $149/mo · 10,000 calls** · **Growth $599/mo · 100,000 calls** (mark "recommended") · **Enterprise $1,999/mo · unlimited (2,000 req/min burst)**. Per-card feature bullets + a "Get API key" CTA. Pull tier details from the README/API-reference rate-limit table so they stay consistent with the product.

### 4.9 — Final CTA **[EDIT-LATER]**
- Headline: **"Self-serve. Live now."** + "Get API key" / "Read the docs."

### 4.10 — Footer **[LOCKED structure, EDIT-LATER links]**
- `progue.` wordmark + tagline "Context infrastructure for supply chain AI."
- Columns: Platform (Modules, Architecture, Guardrails, Pricing) · Developers (Docs, API reference, Changelog) · Company (About, Contact) · Legal (Privacy, Terms, Security).
- Bottom row: © 2026 Progue · status dot "All systems operational" · social (X, GitHub, LinkedIn).

### Sub-pages (lean stubs this build) **[EDIT-LATER]**
- **/pricing** — reuse the pricing cards full-page + an FAQ.
- **/docs** — link out to the real API reference (`docs/api-reference.md`) / hosted docs; a short quickstart. Do not rebuild docs here.
- **/solutions** — one section per buyer type (TMS vendors, freight visibility, 3PL software, procurement SaaS, carrier management). Stub copy now.
- **/about** — short founder/mission paragraph. Stub now.
All four share the nav + footer chrome and the design tokens. Build them as real routes but with minimal content — enough that nav links don't 404.

---

## 5. Animation spec — MODERATE (capped on purpose)

The intensity is **moderate**: one signature hero animation + subtle scroll reveals. Nothing more. This is a deliberate cap to protect build time.

- **Hero trace + code (the one rich animation):** code types out (~40ms/char), then trace lines stream in sequentially (~300ms apart) with status dots, settles, pauses ~3s, loops. Pure CSS/JS or a tiny lib — **no GSAP, no heavy animation framework.** If `prefers-reduced-motion: reduce`, render the finished end-state statically (full code + full trace, no motion).
- **Scroll reveals:** sections fade + translate-up 20px on entering viewport via `IntersectionObserver`, 400ms ease-out, once. That's it.
- **Hover:** buttons darken ~6% (`transition-colors`), pills scale 1.02. Nothing else moves.
- **Explicitly banned for v1:** pinned scroll, parallax, scroll-scrubbed timelines, animated gradients, glow pulses (except the single footer status dot, matching the dashboard). These are the "refine later" bucket — note them as possible v2, do not build them now.

**Performance budget (same as dashboard):** LCP < 2.5s, CLS < 0.1. The hero animation must not cause layout shift — reserve its space.

---

## 6. Editability architecture (your "tweak it later" requirement)

This is a first-class requirement, not a nice-to-have. Build so that **changing copy, pricing, modules, or adding testimonials never requires touching layout/JSX.**

- Create `apps/frontend/src/content/landing.ts` — a single, heavily-commented TypeScript config exporting typed objects for every **[EDIT-LATER]** piece: hero copy, problem cards, module list, pricing tiers, built-on logos, guardrail rows, FAQ, footer links. Components read from this; they contain no hardcoded marketing strings.
- **Pricing** especially lives here as a typed array — editing a price or call-limit is a one-line change, and it should be the *same source* the dashboard billing page reads if feasible (single source of truth for tier data).
- **Adding a Phase 2 module later** = append one object to the modules array. The section renders it automatically.
- **Adding customer logos later** = uncomment/fill a `customers` array; a logo row appears above the "built on" strip with no layout work.
- **Reordering sections** = the page composes from an ordered array of section components; reordering is editing that array.
- Keep all design values in the shared token file (§3) so a palette tweak is also one-line and propagates to both landing page and dashboard.

State the rule to Claude Code explicitly: *all marketing text and data come from `content/landing.ts`; all colors/fonts from the shared token file; components are layout-only.*

---

## 7. Build instructions for Claude Code

- **Location:** `apps/frontend` (the existing Vite app from PR 6.4). The landing page is the public, unauthenticated route(s); the dashboard remains the authenticated routes. Use the existing React Router setup — landing under `/`, sub-pages under `/pricing`, `/docs`, `/solutions`, `/about`; dashboard stays under `/dashboard/*` behind Clerk's `<SignedIn>`.
- **Stack:** React 18 + Vite + TypeScript strict + Tailwind core utilities only (no component libraries, matching the dashboard constraint). Animation in plain CSS/JS — no GSAP/Framer.
- **Tokens:** import the shared theme tokens (§3); do not redefine colors or fonts. If a shared token file doesn't exist yet, create it and point both surfaces at it.
- **Content:** all editable text/data in `content/landing.ts` (§6).
- **Deploy:** reuse the existing `apps/frontend/vercel.json` from PR 6.4 (SPA rewrites already handle client routes; the landing routes are covered by the same rewrite rule). No new deploy config needed — it ships to the same Vercel project as the dashboard.
- **CTAs:** "Get API key" → `https://app.progue.ai/sign-up` (or the Clerk sign-up route). "Read the docs" → the docs route / hosted API reference.
- **Accessibility:** semantic HTML, proper heading hierarchy, focus rings (subtle purple outline), AA contrast, `prefers-reduced-motion` honored on the hero.
- **Output:** build the landing route fully; build the four sub-pages as real-but-lean routes so nav doesn't 404. One section component per section, composed from an ordered array.

---

## 8. Definition of done

- Landing page renders at `/` on the live Vercel domain, visually continuous with the dashboard (same tokens).
- Hero trace+code animation works and degrades to a static end-state under reduced motion.
- All marketing copy/data sourced from `content/landing.ts`; zero hardcoded strings in components.
- Pricing matches the product's real tiers ($149/$599/$1,999) and the API rate-limit table.
- "Get API key" reaches the real signup; "Read the docs" reaches the real docs.
- Four sub-page routes exist and don't 404.
- LCP < 2.5s, CLS < 0.1, no layout shift from the hero.
- Lighthouse pass; `prefers-reduced-motion` verified.

---

## 9. Explicitly deferred (do NOT build now — "ship now, refine later")

These are noted so they're not forgotten, and explicitly excluded from this build to protect the timeline:
- Customer logos / testimonials (until real customers exist — `content.ts` array ready to fill).
- Blog / content-marketing layer (revisit if SEO/content becomes a channel; would justify revisiting Next.js then).
- GSAP-level scroll choreography, parallax, pinned sections.
- Full docs site (link to the existing API reference for now).
- The Progue wave logo (separate track; use the `progue.` wordmark for launch).
- Interactive product playground / live API demo beyond the hero animation.

---

*Plan v1.0 · Build starts only after the 🟣 PR 6.4 domain-live gate · May run parallel to PR 6.5 · Priority: ship the product, the page announces it.*
